
from .server import register_routes

__all__ = ['register_routes']
