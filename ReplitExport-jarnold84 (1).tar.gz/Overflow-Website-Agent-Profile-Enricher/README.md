# 🎯 AI Enrichment Agent (Agent 2)

This AI agent extracts **detailed lead enrichment data** from individual profile URLs.

It is designed to follow up after initial lead discovery (Agent 1), scraping deeper information from personal or faculty pages. Ideal for musicians, educators, therapists, artists, healers, and other professionals.

---

## 🔍 What It Extracts

From a single profile URL, the agent will scrape and analyze the webpage, then extract the following fields:

- `organization` — Institution, ensemble, or company
- `department` — Division or program (if applicable)
- `email` — If publicly available
- `phone` — Contact number if visible
- `city`, `state`, `country` — Geographic location
- `bio` — Short bio or summary of the person
- `relevancy` — "yes" or "no" based on match quality
- `student_demographic` — (If a teacher) age or level of students served
- `priority` — "high", "medium", or "low" based on outreach value

The output is a **valid JSON object**, returned via POST request to the `/extract` endpoint.

---

## 🧠 How It Works

1. Scrapes the text from a single profile page
2. Sends it to OpenAI GPT-4 with a custom prompt
3. Returns a structured JSON object with enriched information

---

## ⚙️ Setup Instructions

### 1. Dependencies (already in `replit.nix`)
- `flask`
- `openai`
- `requests`
- `beautifulsoup4`

### 2. Secrets
Add your OpenAI API key as a secret in **Replit Project Secrets** (not just your account):
- Key: `OPENAI_API_KEY`
- Value: your-api-key-here

### 3. Deploy the App
Use the **Deployments** tab in Replit:
- Target port: `3000` (internal)
- External port: `80` (default)
- Endpoint: `https://<your-replit-username>.<repl-name>.repl.co/extract`

---

## 🚀 How to Use with Make

Use a Make HTTP module configured like this:

- **Method:** POST  
- **URL:** `https://<your-agent-url>.repl.co/extract`  
- **Body Type:** Raw  
- **Content Type:** JSON  
- **Request Body:**
```json
{
  "url": "{{profile_url}}"
}
