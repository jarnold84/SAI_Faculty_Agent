from flask import Flask, request, jsonify
from openai import OpenAI
import os
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

def get_openai_client():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY environment variable is not set")
    return OpenAI(api_key=api_key)

# Universal prompt template with profile links
def extract_leads(page_text: str, profile_links: list, source_url: str):
    prompt = f"""
You are an AI assistant that extracts information about music professionals from web pages.

EXTRACT ALL MUSIC PROFESSIONALS including:
- Musicians, singers, instrumentalists, vocalists
- Music teachers, professors, instructors
- Music producers, engineers, composers
- Music students and faculty
- Anyone involved in music performance, education, or industry

From the following text, extract EVERY person involved in music and their information:
- Name (required)
- Title or role (e.g., "Guitarist", "Recording Engineer", "Music Producer", "Piano Teacher", "Festival Director")
- Email (if available)  
- Lead type (e.g., "Session Musician", "Audio Engineer", "Music Student", "Concert Promoter", "Composer")
- Tags (e.g., classical, jazz, rock, electronic, folk, country, opera, hip-hop, production, engineering, education)
- Short bio or description (if available)
- Relevant social media links (Instagram, Facebook, LinkedIn, YouTube, SoundCloud, Spotify)
- Phone number (if available)
- Website or page URL

PROFILE URL MATCHING RULES:
- For each person you extract, check if their name appears in ANY of the profile links below
- Look for name matches in URLs (case-insensitive):
  * "John Smith" matches URLs containing "john", "smith", "john-smith", "johnsmith", etc.
  * "Sarah Johnson" matches URLs containing "sarah", "johnson", "sarah-johnson", etc.
- If you find a matching URL, include it in the "profile_urls" array
- If no matching URL is found, leave "profile_urls" as an empty array
- ALWAYS extract the person even if no profile URL is found
- Focus on finding ALL music professionals - don't skip people due to missing URLs

Return your output as a valid JSON array of objects. Each object should have these exact fields:
"name", "title", "email", "lead_type", "tags", "bio", "instagram", "facebook", "linkedin", "youtube", "website_url", "profile_urls"

Requirements:
- "website_url" should ALWAYS be: {source_url}
- "profile_urls" should be an array containing any matching URLs from the profile links
- Extract ALL music professionals of any kind - performers, educators, industry workers, students, technicians, etc.
- Aim for comprehensive results - if 50+ music professionals are mentioned, extract them all
- Don't limit to just faculty or formal titles - include session musicians, band members, sound techs, etc.
- Be extremely thorough and inclusive of the entire music ecosystem

If no music professionals are found, return an empty array: []

TEXT TO ANALYZE:
{page_text[:15000]}

POTENTIAL PROFILE LINKS ({len(profile_links)} total):
{profile_links}

SOURCE URL:
{source_url}
"""

    try:
        client = get_openai_client()
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that extracts lead info from websites. Always return valid JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"OpenAI API error: {e}")
        raise e

# Scrape function
def scrape_page(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        res = requests.get(url, timeout=15, headers=headers)
        res.raise_for_status()
        soup = BeautifulSoup(res.text, "html.parser")

        # Extract visible text
        text = soup.get_text(separator="\n")

        # Extract and normalize potential profile links
        links = [a['href'] for a in soup.find_all('a', href=True)]
        from urllib.parse import urljoin
        full_links = [urljoin(url, link) for link in links]

        # Enhanced profile link detection - be more inclusive
        profile_patterns = [
            '/faculty/', '/people/', '/profile/', '/staff/', '/team/', '/bio/',
            '/directory/', '/artist/', '/instructor/', '/teacher/', '/musician/',
            '/member/', '/performer/', '/producer/', '/engineer/', '/student/',
            '/alumni/', '/guest/', '/resident/', '/fellow/', '/composer/',
            '/conductor/', '/talent/', '/roster/', '/lineup/', '/artists/',
            '/musicians/', '/performers/', '/faculty-staff/', '/person/',
            '/profiles/', '/bios/', '/teachers/', '/instructors/', '/crew/',
            '/band-members/', '/orchestra/', '/ensemble/', '/choir/'
        ]

        # Exclude obvious non-profile pages
        exclude_patterns = [
            'mailto:', 'tel:', 'javascript:', '#', '.pdf', '.jpg', '.png', '.gif',
            '/search', '/login', '/contact-us', '/sitemap', '/privacy', '/terms',
            '/news', '/events', '/calendar', '/apply', '/admissions'
        ]

        # Find potential profile links with more inclusive logic
        potential_profiles = []
        for link in full_links:
            link_lower = link.lower()

            # Skip obvious exclusions
            if any(exclude in link_lower for exclude in exclude_patterns):
                continue

            # Include if it matches profile patterns
            if any(pattern in link_lower for pattern in profile_patterns):
                potential_profiles.append(link)
            # Also include links that look like individual profile pages
            elif any(indicator in link_lower for indicator in ['.html', '.htm', '.php']) and \
                 len(link.split('/')) >= 4 and \
                 not link_lower.endswith('/index.html'):
                potential_profiles.append(link)

        # Remove duplicates
        profile_links = list(set(potential_profiles))

        print(f"Found {len(potential_profiles)} potential profiles before deduplication")
        print("Sample profile links:", profile_links[:10])  # limit printout
        print(f"Total unique profile links: {len(profile_links)}")

        return {
            "text": text,
            "profile_links": profile_links
        }
    except Exception as e:
        return {"error": str(e)}

# Routes
@app.route("/")
def home():
    return "AI Lead Agent is running."

@app.route("/extract", methods=["POST"])
def extract():
    try:
        print(f"Received request: {request.get_json()}")
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON data provided"}), 400

        url = data.get("url")
        if not url:
            return jsonify({"error": "No URL provided"}), 400

        print(f"Processing URL: {url}")
        page_data = scrape_page(url)

        if "error" in page_data:
            return jsonify({"error": f"Scraping failed: {page_data['error']}"}), 500

        text = page_data["text"]
        profile_links = page_data["profile_links"]

        print(f"Scraped {len(text)} characters. Found {len(profile_links)} profile links.")
        print("Profile links being sent to AI:", profile_links[:5])  # Show first 5
        print("Sending to GPT...")

        extracted_data = extract_leads(text, profile_links, url)

        import json
        try:
            parsed_data = json.loads(extracted_data)
            # Also include the raw profile links found for debugging
            return jsonify({
                "results": parsed_data, 
                "status": "success",
                "profile_links_found": profile_links[:10],  # First 10 for debugging
                "total_profile_links": len(profile_links)
            })
        except json.JSONDecodeError:
            return jsonify({
                "results": extracted_data, 
                "status": "success", 
                "note": "Response was not valid JSON",
                "profile_links_found": profile_links[:10],
                "total_profile_links": len(profile_links)
            })

    except Exception as e:
        print(f"Error in extract endpoint: {str(e)}")
        return jsonify({"error": str(e), "status": "error"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
